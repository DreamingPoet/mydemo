﻿// Copyright 2022 Xinin Zeng (DreamingPoet). All Rights Reserved.

#include "SPythonFuncBox.h"
#include "PythonHelperStyle.h"
#include "PythonHelper.h"
#include "Widgets/Layout/SScrollBox.h"
#include "../Plugins/Experimental/PythonScriptPlugin/Source/PythonScriptPlugin/Private/PythonScriptPlugin.h"



void SPythonFuncBox::Construct(const FArguments& Args)
{
	FullPath = Args._FullPath;
	FunctionName = Args._FunctionName;

	// 构建UI
	ChildSlot[
		SNew(SButton)
			.OnClicked(this, &SPythonFuncBox::OnExecFunction)
			.ButtonStyle(&FPythonHelperStyle::Get().GetWidgetStyle<FButtonStyle>("PythonHelper.Button.RunFunction"))
			.ContentPadding(FMargin(10))
			[
				SNew(STextBlock).Text(FText::FromString("Call  " + FunctionName)).ColorAndOpacity(FSlateColor(FLinearColor(1, 1, 1, 1)))
			]
	];

}

FReply SPythonFuncBox::OnExecFunction()
{
	FString script = FPythonHelperModule::GetFilePathCharater(FullPath) +"."+ FunctionName;

	FPythonScriptPlugin::Get()->ExecPythonCommand(*script);

	return FReply::Handled();

}
