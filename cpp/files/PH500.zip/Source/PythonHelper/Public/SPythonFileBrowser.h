﻿// Copyright 2022 Xinin Zeng (DreamingPoet). All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Views/STreeView.h"

class SPythonFileItem;

// 元素类型
enum EBrowserTreeType
{
	None,
	Root,
	Directory,
	File
};

// 树状视图元素
class FBrowserElement
{

public:
	// 元素名称
	FString Name;

	// 元素类型
	EBrowserTreeType Type = EBrowserTreeType::Directory;;

	// 文件夹或者文件路径
	FString Path;

	// 该元素的子元素
	TArray<TSharedPtr<FBrowserElement>> Children;

	// 该元素的父元素
	TSharedPtr<FBrowserElement> Parent;

	// 文件的MD5 用来检测文件是否发生变化
	FString MD5;

	FBrowserElement() {
	};

	// 添加一个子元素
	void AddChild(TSharedPtr<FBrowserElement>& Child, TSharedPtr<FBrowserElement>& InParent)
	{
		Child->Parent = InParent;
		Children.Add(Child);
	}


	/**
	 * Equality operator.
	 *
	 * @param Other to compare.
	 * @returns True if this is the same as Other. False otherwise.
	 */
	bool operator==(const FBrowserElement& Other) const
	{
		return Type == Other.Type && Path == Other.Path;
	}

	/**
	 * Inequality operator.
	 *
	 * @param Other to compare.
	 * @returns True if this is NOT the same as Other. False otherwise.
	 */
	FORCEINLINE bool operator!=(const FBrowserElement& Other) const
	{
		return !(*this == Other);
	}
};


// 当一个元素被选中时的代理
DECLARE_DELEGATE_OneParam(FOnElementSelected, TSharedPtr<FBrowserElement>)

/**
 * python文件浏览器
 */
class SPythonFileBrowser : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SPythonFileBrowser)
	{}

	SLATE_EVENT(FOnElementSelected, OnElementSelected)
	SLATE_END_ARGS()

private:

	// 折叠文件夹
	void OnExpansionChanged(TSharedPtr<FBrowserElement> Item, bool bValue);

	// 把python文件的内容转到 FString
	void TransformScriptToString(TSharedPtr<FBrowserElement> Script, OUT TArray< FString >& Array);

	// 重新构建文件树视图
	void RebuldTreeView();

	// 继承自STreeView 
	TSharedRef<ITableRow> OnGenerateRow(TSharedPtr<FBrowserElement> Item, const TSharedRef<STableViewBase>& OwnerTable);
	void OnGetChildren(TSharedPtr<FBrowserElement> Item, TArray<TSharedPtr<FBrowserElement>>& OutChildren);

	void OnSelectStateChanged(TSharedPtr<FBrowserElement> Item);

	// 收集所有文件及目录，从根节点开始构建文件树
	void GenerateChildrenTree(TSharedPtr<FBrowserElement> TheBrowserElement, TArray<TSharedPtr<FBrowserElement>>& LinearOut);

public:

	// Widget的构造函数，必须实现
	void Construct(const FArguments& Args);

	// 更新目录
	void BrowserUpdate();

	// 获取最后一个选中的元素
	TSharedPtr<FBrowserElement> GetLastSelection();

	// 清除选中的元素
	void ClearSelection();

private:
	// 选中元素的代理
	FOnElementSelected OnElementSelected;

	// 保存最后一个选择元素
	TSharedPtr<FBrowserElement> LastSelection;

	// STreeView
	TSharedPtr<STreeView<TSharedPtr<FBrowserElement>>> FileTreeView;

	// 根目录
	TArray<TSharedPtr<FBrowserElement>> RootDirectory;

	// 文件浏览器容器 
	TSharedPtr<SVerticalBox> Container;

	// 所有文件和文件夹
	TArray<TSharedPtr<FBrowserElement>> AllElements;

	// 存放所有元素
	TArray<TSharedPtr<class SPythonFileItem>> Items;

	// 已经展开的元素
	TSet<TSharedPtr<FBrowserElement>> ExpandedItems;
};
