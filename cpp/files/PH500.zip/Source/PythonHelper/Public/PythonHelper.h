﻿// Copyright 2022 Xinin Zeng (DreamingPoet). All Rights Reserved.
#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class FToolBarBuilder;
class FMenuBuilder;
class FBrowserElement;
class SPythonFileBrowser;
class SDockTab;
class SCheckBox;

class FPythonHelperModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
	
	/** This function will be bound to Command (by default it will bring up plugin window) */
	void PluginButtonClicked();

	//~ Get Project script directory
	static FString GetPythonDirectory()
	{
		return FPaths::ConvertRelativePathToFull(FPaths::ProjectDir()) + "Python";
	}


	// 获取文件路径的字符，用于导入模块，防止重名
	static FString GetFilePathCharater(const FString Path);

	static FString PluginDirectory;
private:

	void RegisterMenus();

	TSharedRef<class SDockTab> OnSpawnPluginTab(const class FSpawnTabArgs& SpawnTabArgs);

private:
	TSharedPtr<class FUICommandList> PluginCommands;

	// 生成所有函数按钮
	void GenerateFunctionButtons(TSharedPtr<FBrowserElement> Item);

	// 函数容器 
	TSharedPtr<SVerticalBox> FunctionContainer;

	// 文件浏览器
	TSharedPtr<SPythonFileBrowser> PythonFileBrowser;

	// python文件方法栏-名称文本框
	TSharedPtr<STextBlock> PythonFilenameText;

	// 是否开启自动刷新
	void OnAutoRefreshPythonFile(ECheckBoxState NewState);
	bool bAutoRefresh = true;

	// 当前的文件,需要定时刷新
	TSharedPtr<FBrowserElement> CurrentItem;

	// 生成所有的方法按钮
	void GenerateFunctions(const FString Code, const FString Path);

	FTimerHandle TimerHander;
	void TimerCall(bool bForceEndChange = false);

	// 当面板关闭的时候
	void OnTabClosed(TSharedRef<SDockTab> Tab);

	// 检查和复制依赖文件
	void CheckDependencies();

	void OnPythonInitialized();
};
