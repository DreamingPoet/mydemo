﻿// Copyright 2022 Xinin Zeng (DreamingPoet). All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "SPythonFileBrowser.h"


/**
 * 文件浏览器中每个元素的UI
 */
class SPythonFileItem : public SCompoundWidget 
{
public:

	SLATE_BEGIN_ARGS(SPythonFileItem)
	{}

	SLATE_ARGUMENT(TSharedPtr<class SPythonFileBrowser>, TheBrowser)
	SLATE_ARGUMENT(TSharedPtr<FBrowserElement>, TheBrowserElement)
	SLATE_EVENT(FOnElementSelected, OnSelectStateChanged)

	SLATE_END_ARGS()

	void SetSelected(const bool& bSelected);

private:

	// SWidget
	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	// 该UI 所持有的文件树中的元素
	TSharedPtr<FBrowserElement> FileTree;

	// 文件浏览器
	TSharedPtr<class SPythonFileBrowser> PythonFileBrowser;

	// 当元素被选中的时候
	FOnElementSelected OnSelectStateChanged;


	// 当点击执行按钮的时候
	FReply OnRunButtonClicked();

	// 该元素是否被选中
	bool bIsSelected = false;

	// UI 边框，做选中效果
	TSharedPtr<class SBorder> SelectedBorder;


public:
	// UI的构造方法，必须实现此方法
	void Construct(const FArguments& Args);
};

