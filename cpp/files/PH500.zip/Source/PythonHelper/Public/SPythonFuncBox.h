// Copyright 2022 Xinin Zeng (DreamingPoet). All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"

/**
 * python 函数
 */
class SPythonFuncBox : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SPythonFuncBox)
	{}


	SLATE_ARGUMENT(FString, FullPath)
	SLATE_ARGUMENT(FString, FunctionName)
	SLATE_END_ARGS()

private:


public:

	// Widget的构造函数，必须实现
	void Construct(const FArguments& Args);

	FReply OnExecFunction();


private:
	FString FullPath;
	FString FunctionName;

};
