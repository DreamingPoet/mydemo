﻿// Copyright 2022 Xinin Zeng (DreamingPoet). All Rights Reserved.

using UnrealBuildTool;

public class PythonHelper : ModuleRules
{
	public PythonHelper(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		
		PublicIncludePaths.AddRange(
			new string[] {
				// ... add public include paths required here ...
			}
			);
				
		
		PrivateIncludePaths.AddRange(
			new string[] {
				// ... add other private include paths required here ...
			}
			);
			
		
		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				// ... add other public dependencies that you statically link with here ...
			}
			);
			
		
		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"Projects",
				"InputCore",
				"UnrealEd",
				"ToolMenus",
				"CoreUObject",
				"Engine",
				"Slate",
				"SlateCore",
                "PythonScriptPlugin",
				"EditorScriptingUtilities"
				// ... add private dependencies that you statically link with here ...	
			}
			);


        BuildVersion Version;
        if (BuildVersion.TryRead(BuildVersion.GetDefaultFileName(), out Version))
        {
			if (Version.MinorVersion > 25 || Version.MajorVersion > 4)
			{
				PrivateDependencyModuleNames.Add("Python3");
			}
			else
			{
				PrivateDependencyModuleNames.Add("Python");
			}
        }

        DynamicallyLoadedModuleNames.AddRange(
			new string[]
			{
				// ... add any modules that your module loads dynamically here ...
			}
			);
	}
}
