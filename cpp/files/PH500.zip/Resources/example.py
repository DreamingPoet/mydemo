# Copyright 2022 Xinin Zeng (DreamingPoet). All Rights Reserved.

try:
    import unreal
except:
    from unreallib import unreallib as unreal

import sys


class MyObj():
    def __init__(self):
        self.name = "MyObj"
        pass

    def hello(self):
        print(self.name + ":" + "Hello Python!")

# Only module functions without parameters can be 
# recognized by PythonHelper plugin.
def say_hello():
    a = MyObj()
    a.hello()

# show python version of the current UnrealEngine
def get_python_version():
    print(sys.version)

# spawn actor
def spawn_actor():
    _class = unreal.EditorAssetLibrary.load_blueprint_class(
        '/Engine/Tutorial/SubEditors/TutorialAssets/Character/TutorialCharacter.TutorialCharacter'
    )
    location = unreal.Vector(0, 0, 90)
    rotation = unreal.Rotator(0, 0, -70)
    unreal.EditorLevelLibrary.spawn_actor_from_class(_class, location,rotation)
    location = unreal.Vector(0, 150, 90)
    rotation = unreal.Rotator(0, 0, -160)
    unreal.EditorLevelLibrary.spawn_actor_from_class(_class, location,rotation)
    location = unreal.Vector(150, 150, 90)
    rotation = unreal.Rotator(0, 0, 110)
    unreal.EditorLevelLibrary.spawn_actor_from_class(_class, location,rotation)


# destroy actor
def destroy_actor():
    
    a = unreal.EditorLevelLibrary.get_all_level_actors()

    # important!!! the following type of declaration is needed for the intelligence code prompt in a for_loop
    # i:unreal.Actor # python version < 3.5 will raise an error

    for i in a:
        if("TutorialCharacter" in i.get_full_name()):
            # print(i.get_full_name())
            i.destroy_actor()